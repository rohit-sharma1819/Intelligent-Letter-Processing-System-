from ultralytics import YOLO

# Download YOLOv8 small model
model = YOLO("best.pt")  # Use your trained model
print("YOLOv8 model downloaded successfully.")
